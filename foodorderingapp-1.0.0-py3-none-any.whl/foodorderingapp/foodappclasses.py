# Model file of the project

from datetime import timedelta
import sqlite3 as sql
import numpy as np
from geopy.distance import geodesic
from datetime import datetime
from datetime import timedelta


class database:  # Class for connectivity to Database

    __dbname = 'project.db'
    __conn = ""

    def openconnection(self):  # Connect to database for CRUD operations
        self.__conn = sql.connect(self.__dbname)
        return self.__conn

    def closeconnection(self):  # Close connection once the operations are done
        self.__conn.close()


class user(database):  # Class for app user

    # private members(Encapsulation)
    __uname = ""
    __email = ""
    __mobno = ""
    __pass = ""
    __coupon1 = 1
    __coupon2 = 1
    __wallet = 0
    __address = tuple()

    def __init__(self, data):  # Parameterised Construtor
        self.__email = data[0]
        self.__pass = data[1]

    def getname(self):  # getter for username
        return self.__uname

    def validate(self):  # Function to Check if the user already exists
        conn = self.openconnection()  # using inherited method fromdatabase class
        email = self.__email
        cur = conn.cursor()
        cur.execute('''
        select * 
        from users
        where email= ?''', (email,))
        check = cur.fetchall()
        self.closeconnection()
        if(len(check) > 0):
            return False
        else:
            return True

    def insert(self, data):  # Function to insert user details to database
        conn = self.openconnection()
        cur = conn.cursor()
        user = [self.__email,
                data[2],
                data[3],
                self.__pass,
                self.__coupon1,
                self.__coupon2,
                self.__wallet]
        cur.execute('''
        insert 
        into users
        values(?,?,?,?,?,?,?)''', user)
        conn.commit()
        self.closeconnection()

    def auth(self):  # To authorsise user to the app if user is available
        check = self.fetch()
        if(len(check) > 0):
            return True
        else:
            return False

    def fetch(self):  # To Fetch User record from Database
        conn = self.openconnection()  # using inherited method fromdatabase class
        cur = conn.cursor()
        data = [self.__email, self.__pass]
        cur.execute('''
        select * 
        from users
        where email = ? and pass= ?
        ''', data)
        record = cur.fetchall()
        self.closeconnection()
        return record

    def setaddress(self):  # To set user location
        defadd = np.array([23.535, 87.295])
        self.__address = tuple(defadd - np.random.uniform(-0.005, 0.005))

    def getaddress(self):  # getter for user location
        return self.__address

    def getwallet(self):  # getter method for wallet amount
        return self.__wallet

    # To fetch user record on login and set the class attribute
    def fetchnsetuserdata(self):
        record = self.fetch()[0]
        self.__uname = record[2]
        self.__email = record[0]
        self.__mobno = record[1]
        self.__pass = record[3]
        self.__coupon1 = record[4]
        self.__coupon2 = record[5]
        self.__wallet = record[6]

    def getcouponstatus(self):  # To get coupon status for loggedin user
        return [self.__coupon1, self.__coupon2]

    def getemail(self):  # getter method for user email
        return self.__email

    # Update coupon status once the coupon has been used by the logged in user
    def updatecouponstat(self, disfac):

        if disfac == 0.5:
            conn = self.openconnection()  # using inherited method fromdatabase class
            cur = conn.cursor()
            email = self.__email
            cur.execute('''
            update users
            set coupon1 = 0           
            where email = ? 
                    ''', (email,))
            conn.commit()
            self.closeconnection()

        if disfac == 0.8:
            conn = self.openconnection()
            cur = conn.cursor()
            email = self.__email
            cur.execute('''
            update users
            set coupon2 = 0           
            where email = ? 
                    ''', (email,))
            conn.commit()
            self.closeconnection()


class restaurants(database):  # class restuarant for restaurant available on the app

    __rid = ""
    __rname = ""
    __lon = ""
    __lat = ""
    __rating = ""
    __preptime = 20

    def fetchall(self):  # Fetch all the records from the restaurant database
        conn = self.openconnection()
        cur = conn.cursor()
        cur.execute('''
        select * 
        from restaurants
        ''')
        record = cur.fetchall()
        self.closeconnection()
        return record

    # Polymorphism
    def fetch(self, rid):  # Method to query the restaurnat table based on the user selection
        conn = self.openconnection()
        cur = conn.cursor()
        cur.execute('''
        select * 
        from restaurants
        where rid = ?
        ''', (rid,))
        record = cur.fetchall()[0]
        self.closeconnection()
        return record

    # setter method for restaurant datamembers
    def fetchandsetrestaurant(self, rid):
        record = self.fetch(int(rid))
        self.__rid = record[0]
        self.__rname = record[1]
        self.__lon = record[2]
        self.__lat = record[3]
        self.__rating = record[4]

    # Function to  get ETA for delivery from restaurant to the user
    def calculateeta(self, usradd):
        misctime = np.random.uniform(-5, 10)
        loc1 = (self.__lon, self.__lat)
        loc2 = usradd
        dist = geodesic(loc1, loc2)
        traveltime = (dist.km*60/20)
        eta = int(traveltime + self.__preptime + misctime)
        return [dist.km, eta]


class menu(restaurants):  # Class menu for menu details of a particular restaurant selected by the user

    __rid = ""
    __fooditem = ""
    __price = ""
    __qty = ""

    # Another use of polymorphism(same functionname used in restaurant class)
    def fetchall(self, rid):
        conn = self.openconnection()  # using inherited method fromdatabase class
        cur = conn.cursor()
        cur.execute('''
        select * 
        from menu
        where rid = ?
        ''', (rid,))
        record = cur.fetchall()
        self.closeconnection()
        return record


class cart(menu):  # class cart for selected food items with price, qty and amount as datamembers

    __fooditem = ""
    __price = ""
    __qty = ""
    __amount = 0

    def __init__(self, cart):  # Parameteised constructor for the class
        self.__fooditem = [cart[i][0] for i in range(len(cart))]
        self.__price = [cart[i][1] for i in range(len(cart))]
        self.__qty = [cart[i][2] for i in range(len(cart))]

    def calculatebill(self):  # Calculate bill for the cart
        for i in range(len(self.__price)):
            self.__amount += (int(self.__price[i])*int(self.__qty[i]))
            print(self.__amount)

    def getamount(self):  # getter method for private data member amount
        return self.__amount


class payment():  # Class for payment

    __fixeddelchg = 5
    __deliverycharges = 0
    __devchgperkm = 5
    __total = 0

    def deliverycharges(self, dist):  # Method to calculate delivery Charges
        self.__deliverycharges = self.__fixeddelchg + dist*self.__devchgperkm
        return self.__fixeddelchg + dist*self.__devchgperkm

    def finalpayment(self, disfac, amount, wallet):  # Method to calculate total payment
        self.__total = disfac*(self.__deliverycharges +
                               amount - wallet)
        return self.__total


# Class Banking Detail which is inheriting payment class
class bankingdetail(database, payment):

    __mobno = ""
    __uname = ""
    __email = ""
    __balance = ""
    __ccno = ""
    __dcno = ""
    __pin = ""

    def __init__(self, email):  # Parametized Constructor for the class
        self.__email = email

    # Usage of polymorphism shown here
    def fetch(self):  # Member Function to get banking data from banking table
        conn = self.openconnection()
        cur = conn.cursor()
        cur.execute('''
        select * 
        from bankingdetails
        where email = ?
        ''', (self.__email,))
        record = cur.fetchall()[0]
        self.closeconnection()
        return record

    def fetchnsetbd(self):  # Setter Method for the class
        record = self.fetch()
        self.__mobno = record[0]
        self.__uname = record[1]
        self.__email = record[2]
        self.__balance = record[3]
        self.__ccno = record[4]
        self.__dcno = record[5]
        self.__pin = record[6]

    def validate(self, paydet):  # Validate banking credentials of the user
        if(paydet[0] == "1") and (int(self.__mobno) == int(paydet[1])) and (int(self.__pin) == int(paydet[2])):
            flag = True
        elif(paydet[0] == "2") and (self.__email == paydet[1]) and (int(self.__pin) == int(paydet[2])):
            flag = True
        elif(paydet[0] == "3") and (int(self.__dcno) == int(paydet[1])) and (int(self.__pin) == int(paydet[2])):
            flag = True
        elif(paydet[0] == "4") and (int(self.__ccno) == int(paydet[1])) and (int(self.__pin) == int(paydet[2])):
            flag = True
        else:
            flag = False

        return flag


class order(cart):  # Class for keeping the order details

    __rid = ""
    __email = ""
    __amount = ""
    __ordertime = ""
    __scheduledarrival = ""
    __expectedarrival = ""
    __rating = ""

    # Parameteised constructor for the order class
    def __init__(self, roption, email, tamount, ordertime, scheduledarrival):
        self.__rid = roption
        self.__email = email
        self.__amount = tamount
        self.__ordertime = ordertime
        self.__scheduledarrival = scheduledarrival

    def timedif(self):  # Method to check if their is any delay in order
        randomfactor = int(np.random.uniform(-10, 20))
        if (randomfactor < 4):
            return True
        else:
            return False

    # getter method for the private datamember scheduledarrival
    def getscheduledarrival(self):
        return self.__scheduledarrival

    def setrating(self, rating):  # setter method for the rating given by user
        self.__rating = rating

    # getter method for the private datamember expected arrival
    def getexpectedarrival(self):
        return self.__expectedarrival
