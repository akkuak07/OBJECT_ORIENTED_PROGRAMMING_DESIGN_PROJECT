# Controller file for the project

import foodappui as ui
import foodappclasses as clss
from datetime import datetime
from datetime import timedelta


def appflow():  # Controller function maintaining the flow of the app

    # Calls the mainmenu function from the ui module for the app and get user option
    option = ui.mainmenu()
    if option == 1:
        data = ui.signupmenu()  # Calls the signupmenu from ui module and get user input
        userObj = clss.user(data)  # Creating the userobj
        if userObj.validate():  # Validating the user input
            userObj.insert(data)  # Inserting the new user into the database
            ui.welcomemsg(userObj.getname())
            appflow()  # Going back too the Mainpage once new user is registered
        else:
            ui.alreadyexists()  # If the email already used show the message and
            appflow()  # take user back to main menu

    elif option == 2:  # Option for taking user to the login menu
        data = ui.loginmenu()  # showing user the login menu and getting user data
        userObj = clss.user(data)  # Creating user obj with input data
        if userObj.auth():  # checking if the user credentails are valid
            # fetching all user detail from database and setting the datamembers of the user object
            userObj.fetchnsetuserdata()
            ui.welcomemsg(userObj.getname())
            userObj.setaddress()  # Setting user location
            usradd = userObj.getaddress()  # getting user address location
            rObj = clss.restaurants()  # Creating restaurants object
            rdetails = rObj.fetchall()  # Fetching restaurant details from the database
            # Showing user the restaurant and getting user selection
            roption = ui.showrestaurants(rdetails)
            # Setting restaurant datamembers based on the record fetched
            rObj.fetchandsetrestaurant(roption)
            # Calculating eta from restaurant to the user address
            devdata = rObj.calculateeta(usradd)
            eta = devdata[1]
            mObj = clss.menu()  # Creating object for the menu class
            # fetching the Menu of the selected restaurant
            mdetails = mObj.fetchall(roption)
            # Showing food Menu to user and selcting his/her input
            cart = ui.showmenu(mdetails, devdata[1])
            if len(cart) == 0:  # checking if the cart is empty
                ui.exitmsg()
                appflow()  # taking  user to homepage if cart is empty
            else:
                # Creating the obj of the cart class
                cartObj = clss.cart(list(cart.values()))
                cartObj.calculatebill()  # calculating the total amount of the cart
                amount = cartObj.getamount()  # getting the amount of the cart
                if(amount < 100):  # Checking if the cart value is less than 100
                    ui.amountless()
                    appflow()  # taking user back to homepage if cart amount is less
                else:
                    paymentObj = clss.payment()  # Creating the object of the payment class
                    # Calculating delivery charges baed on the distance
                    deliverychg = paymentObj.deliverycharges(devdata[0])
                    # Getting available coupon sto the user
                    couponstatus = userObj.getcouponstatus()
                    # Showbill breakup to user
                    wallet = userObj.getwallet()
                    disfac = ui.showbill(
                        amount, deliverychg, couponstatus, wallet)
                    # Updating the user coupon status on the database if used
                    userObj.updatecouponstat(disfac)
                    # Calculating the final total of the order
                    tamount = paymentObj.finalpayment(disfac, amount, wallet)
                    while(True):
                        # giving user the option to select from the various payment methods and getting his/her input creds
                        paydet = ui.paymentmethod(tamount)
                        email = userObj.getemail()  # getting user email
                        # getting user banking details
                        bdObj = clss.bankingdetail(email)
                        bdObj.fetchnsetbd()  # settingg user banking details to the datamember of the class
                        # checking if the user banking details are correct
                        validflag = bdObj.validate(paydet)
                        if validflag:  # Checking if user creds are valid
                            ui.paymentdone()
                            ordertime = datetime.now().strftime("%H:%M")  # getting order time
                            sat = datetime.now() + timedelta(minutes=eta)  # getting scheduled arrival time
                            scheduledarrival = sat.strftime("%H:%M")
                            orderObj = clss.order(
                                roption, email, tamount, ordertime, scheduledarrival)  # creating obect for the order class
                            tflag = orderObj.timedif()  # checking timediffernce in expected and scheduled arrival
                            scharrtime = orderObj.getscheduledarrival()  # getting scheduled arrival
                            # Showing Current status for the food order and getting the rating
                            rating = ui.tracking(tflag, scharrtime)
                            # seting the rating given by the user
                            orderObj.setrating(rating)
                            break
                        else:
                            ui.invaliddata()
            appflow()

        else:
            ui.invaliddata()
            appflow()

    else:
        ui.exitmsg()
        ui.os.system('exit')


if __name__ == "__main__":
    appflow()
